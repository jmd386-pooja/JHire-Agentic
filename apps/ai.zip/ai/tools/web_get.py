from __future__ import annotations
"""
tools.web_get
----------------
HTTP GET + light content extraction for the ReAct tool layer.
"""
from typing import Dict, Any, List

try:
    import requests
    from bs4 import BeautifulSoup
except Exception:  # pragma: no cover
    requests = None
    BeautifulSoup = None

def _extract_readable_text(html: str) -> Dict[str, Any]:
    if not BeautifulSoup:
        return {"title": None, "text": None, "links": [], "note": "bs4 not installed"}
    soup = BeautifulSoup(html, "html.parser")
    title = (soup.title.string or "").strip() if soup.title and soup.title.string else ""
    parts: List[str] = []
    for tag in soup.find_all(["p", "li", "h1", "h2", "h3"]):
        txt = tag.get_text(" ", strip=True)
        if txt:
            parts.append(txt)
    text = "\n".join(parts)[:100000]
    links = []
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if href and not href.startswith("#"):
            links.append({"text": a.get_text(" ", strip=True), "url": href})
    return {"title": title, "text": text, "links": links}

def run_web_get(args: Dict[str, Any]) -> Dict[str, Any]:
    url = (args or {}).get("url")
    if not isinstance(url, str) or not url.strip():
        return {"ok": False, "error": "invalid_args", "hint": "Expected 'url': non-empty string"}
    if not requests:
        return {"ok": False, "error": "requests_not_available"}
    try:
        resp = requests.get(url, timeout=15)
        meta = {"status": resp.status_code, "url": url}
        if resp.status_code != 200:
            return {"ok": False, "error": "http_error", **meta}
        parsed = _extract_readable_text(resp.text)
        return {"ok": True, **parsed, **meta}
    except Exception as e:
        return {"ok": False, "error": f"http_exception:{e}", "url": url}
