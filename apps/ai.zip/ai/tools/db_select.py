from __future__ import annotations
"""
tools.db_select
------------------
Safe DB question answering tool:
1) Convert natural-language question to SQL via nl2sql.sql_select(..., limit=50).
2) Validate it's a SELECT with a LIMIT and no dangerous tokens.
3) Execute via the provided MCP client (execute_database_query or call_tool).

Return shape (Observation-like):
    {"ok": True, "rows": [...], "sql": "SELECT ... LIMIT ..."}  # success
    {"ok": False, "error": "...", "sql"?: "..."}               # failure
"""
from typing import Dict, Any, List, Optional
import re

try:
    # Relative import from the ai package (adjust if your package layout differs)
    from ai import nl2sql
except Exception:  # pragma: no cover
    nl2sql = None 


_SELECT_RE = re.compile(r"^\s*select\s", re.IGNORECASE | re.DOTALL)

def _is_safe_select(sql: str) -> bool:
    """Allow only SELECT with no obvious DDL/DML and no semicolons."""
    if not isinstance(sql, str) or not _SELECT_RE.search(sql or ""):
        return False
    lo = f" {sql.lower()} "
    bad = [" insert ", " update ", " delete ", " drop ", " alter ", " create ", " grant ", " revoke ", ";"]
    return not any(tok in lo for tok in bad)

def _ensure_limit(sql: str, default_limit: int = 50) -> str:
    """Ensure a LIMIT clause exists; if not, append one."""
    if not isinstance(sql, str):
        return ""
    lo = sql.lower()
    if " limit " in lo:
        return sql
    return sql.rstrip() + f" LIMIT {default_limit}"

def _schema_text_from_mcp(mcp_client: Any) -> str:
    """Build a compact schema text using MCP get_database_stats if available."""
    if mcp_client is None:
        return ""
    try:
        # Try direct method
        if hasattr(mcp_client, "get_database_stats"):
            info = mcp_client.get_database_stats()
        # Try via call_tool
        elif hasattr(mcp_client, "call_tool"):
            info = mcp_client.call_tool("get_database_stats", {})
        else:
            return ""
        if not isinstance(info, dict):
            return ""
        tables = info.get("tables") or []
        lines: List[str] = []
        for t in tables:
            tname = t.get("name", "")
            cols = ", ".join(c.get("name", "?") for c in t.get("columns", []))
            if tname:
                lines.append(f"{tname}: {cols}")
        return "\n".join(lines)
    except Exception:
        return ""

def run_db_select(args: Dict[str, Any], mcp_client: Any) -> Dict[str, Any]:
    """
    Args:
        args: {"question": str}
        mcp_client: object exposing execute_database_query(sql) or call_tool("execute_database_query", {"sql": ...})
    """
    question = (args or {}).get("question")
    if not isinstance(question, str) or not question.strip():
        return {"ok": False, "error": "invalid_args", "hint": "Requires 'question': non-empty string"}

    if nl2sql is None:
        return {"ok": False, "error": "nl2sql_not_available"}

    schema_text = _schema_text_from_mcp(mcp_client)

    # 1) NL2SQL
    try:
        sql = nl2sql.sql_select(question.strip(), schema_text=schema_text, limit=50)  # type: ignore[attr-defined]
    except Exception as e:
        return {"ok": False, "error": f"nl2sql_error:{e}"}

    # 2) Safety checks + LIMIT
    sql = _ensure_limit(sql, default_limit=50)
    if not _is_safe_select(sql):
        return {"ok": False, "error": "unsafe_sql", "sql": sql}

    # 3) Execute via MCP
    try:
        if hasattr(mcp_client, "execute_database_query"):
            res = mcp_client.execute_database_query(sql)
        elif hasattr(mcp_client, "call_tool"):
            res = mcp_client.call_tool("execute_database_query", {"sql": sql})
        else:
            return {"ok": False, "error": "mcp_client_missing_execute", "sql": sql}

        obs: Dict[str, Any] = {"ok": True, "sql": sql}
        if isinstance(res, dict) and "rows" in res:
            obs["rows"] = res["rows"]
        else:
            # Generic shape
            obs["data"] = res
        return obs
    except Exception as e:
        return {"ok": False, "error": f"db_execute_error:{e}", "sql": sql}
