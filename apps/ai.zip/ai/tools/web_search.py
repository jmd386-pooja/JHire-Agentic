from __future__ import annotations
"""
tools.web_search (free providers)
-----------------------------------
Best-effort web search using **free** options:
1) duckduckgo_search (pip install duckduckgo-search) — general web search
2) Wikipedia MediaWiki API — fallback for encyclopedic queries
"""
from typing import Dict, Any, List

try:
    from duckduckgo_search import DDGS  # type: ignore
except Exception:
    DDGS = None  # type: ignore

try:
    import requests
except Exception:  # pragma: no cover
    requests = None


def _search_duckduckgo(q: str, k: int) -> Dict[str, Any]:
    if DDGS is None:
        return {"ok": False, "error": "duckduckgo_search_not_installed"}
    try:
        hits: List[Dict[str, Any]] = []
        with DDGS() as ddgs:
            for r in ddgs.text(q, max_results=k):
                if not isinstance(r, dict):
                    continue
                title = r.get("title") or ""
                url = r.get("href") or ""
                snippet = r.get("body") or ""
                if title and url:
                    hits.append({"title": title, "url": url, "snippet": snippet})
                if len(hits) >= k:
                    break
        if hits:
            return {"ok": True, "hits": hits, "provider": "duckduckgo"}
        return {"ok": False, "error": "no_results", "provider": "duckduckgo"}
    except Exception as e:
        return {"ok": False, "error": f"duckduckgo_error:{e}"}


def _search_wikipedia(q: str, k: int) -> Dict[str, Any]:
    if requests is None:
        return {"ok": False, "error": "requests_not_available"}
    try:
        params = {
            "action": "query",
            "list": "search",
            "srsearch": q,
            "srlimit": max(1, min(k, 20)),
            "format": "json",
            "utf8": 1,
            "origin": "*",
        }
        resp = requests.get("https://en.wikipedia.org/w/api.php", params=params, timeout=15)
        if resp.status_code != 200:
            return {"ok": False, "error": f"wikipedia_http_{resp.status_code}"}
        data = resp.json()
        items = data.get("query", {}).get("search", []) or []
        hits: List[Dict[str, Any]] = []
        for it in items[:k]:
            title = it.get("title", "")
            snippet_html = it.get("snippet", "")
            snippet = snippet_html.replace("<span class=\"searchmatch\">", "").replace("</span>", "")
            url_title = title.replace(" ", "_")
            url = f"https://en.wikipedia.org/wiki/{url_title}"
            hits.append({"title": title, "url": url, "snippet": snippet})
        if hits:
            return {"ok": True, "hits": hits, "provider": "wikipedia"}
        return {"ok": False, "error": "no_results", "provider": "wikipedia"}
    except Exception as e:
        return {"ok": False, "error": f"wikipedia_error:{e}"}


def run_web_search(args: Dict[str, Any]) -> Dict[str, Any]:
    q = (args or {}).get("q") or ""
    k = int((args or {}).get("k") or 5)
    if not isinstance(q, str) or not q.strip():
        return {"ok": False, "error": "invalid_args", "hint": "Expected 'q': non-empty string", "args": args}
    if k < 1 or k > 20:
        k = max(1, min(k, 20))

    res = _search_duckduckgo(q.strip(), k)
    if res.get("ok"):
        return res

    res2 = _search_wikipedia(q.strip(), k)
    if res2.get("ok"):
        return res2

    return {
        "ok": False,
        "error": "all_free_providers_failed",
        "query": q,
        "k": k,
        "duckduckgo": {k: v for k, v in res.items() if k != "hits"},
        "wikipedia": {k: v for k, v in res2.items() if k != "hits"},
    }
