"""
ReAct Prompt Template
---------------------
This module provides a reusable, production-ready prompt template for a ReAct-style agent:
- Interleaves Thought -> Action(JSON) -> Observation steps.
- Encourages evidence-first answers and finishing with a structured Finish action.
- Supports dynamic tool catalogs (inserted at runtime).
- Includes few-shot examples for web, DB (NL2SQL -> db.select), and safe email usage.

Usage:
    from prompts.react_prompt import make_react_prompt, REACT_SYSTEM_PROMPT

    prompt = make_react_prompt(
        goal="Find the CEO of Acme Corp and their 2024 compensation; cite sources.",
        tools=tool_specs,  # dict[str, ToolSpec-like], each contains name, description, schema
        reflections=["If page parsing fails, try another source."],
        max_steps=7,
    )
"""

from __future__ import annotations
from typing import Dict, Any, Iterable, Optional
import json


REACT_SYSTEM_PROMPT = """You are a ReAct-style agent. You must reason step-by-step and interleave:
- Thought: a brief plan or reflection written for yourself (do not roleplay).
- Action: a SINGLE JSON object on the SAME line after the literal 'Action: '.
- Observation: the tool result (you will receive this from the system).

You have access only to the registered tools listed below.
You MUST follow this strict format at each step:

Thought: <brief reasoning, 1-2 sentences>
Action: {"tool": "<TOOL_NAME>", "args": { ... }}

# After an Action is executed, you will receive an Observation. Then continue with:
Thought: <reflect on the observation, update plan>
Action: {"tool": "<TOOL_NAME>", "args": { ... }}

# Finish the task when you are ready with a final answer:
Action: {"tool": "Finish", "args": {"answer": "<final answer text>", "evidence": [<optional citations or data>]}}

POLICIES:
- Prefer grounded answers: consult tools (web, db, files) before finishing for factual tasks.
- Use at most ONE tool per step; do NOT emit multiple actions in one turn.
- Keep Thoughts concise (1-2 sentences). Avoid repeating the same plan (detect loops).
- If a tool returns an error in Observation, analyze why and fix your next Action.
- If you cannot obtain reliable evidence within the step limit, provide your best effort with uncertainty notes.
- For irreversible actions (e.g., sending email, deployments), request explicit approval or stop at a draft step.
- Hard step cap: MAX_STEPS = {max_steps}. If you reach this cap without finishing, synthesize your best answer with uncertainties.

DO NOT include additional keys in Action JSON other than "tool" and "args".
DO NOT write anything after the JSON on the Action line.
"""

# ---------- Few-shot examples (kept compact but illustrative) ----------
FEW_SHOT_WEB = """\
# Example: Web search and fetch a page, then finish with evidence
Goal: What is the capital of Japan? Cite a source.

Thought: I should search for the capital of Japan from a reliable source.
Action: {"tool": "web.search", "args": {"q": "capital of Japan site:wikipedia.org", "k": 3}}
Observation: [{"title": "Japan - Wikipedia", "url": "https://en.wikipedia.org/wiki/Japan", "snippet": "... capital is Tokyo ..."}]

Thought: I'll open the Wikipedia page to confirm the capital.
Action: {"tool": "web.get", "args": {"url": "https://en.wikipedia.org/wiki/Japan"}}
Observation: {"title": "Japan - Wikipedia", "text": "... Japan ... capital is Tokyo ...", "status": 200}

Thought: I have sufficient evidence to answer and can cite the page.
Action: {"tool": "Finish", "args": {"answer": "Tokyo.", "evidence": ["https://en.wikipedia.org/wiki/Japan"]}}
"""

FEW_SHOT_DB = """\
# Example: Natural-language DB question via db.select (NL2SQL under the hood)
Goal: How many candidates named Priya are in the database? Show the count.

Thought: I should query the database safely with a SELECT+LIMIT enforced tool.
Action: {"tool": "db.select", "args": {"question": "Count candidates named Priya"}}
Observation: {"ok": true, "rows": [{"count": 12}], "sql": "SELECT COUNT(*) AS count FROM \\"Candidate\\" WHERE name ILIKE '%Priya%';"}

Thought: I have the count from the DB.
Action: {"tool": "Finish", "args": {"answer": "There are 12 candidates named Priya in the database.", "evidence": [{"sql": "SELECT COUNT(*) AS count FROM \\"Candidate\\" WHERE name ILIKE '%Priya%';"}]}}
"""

FEW_SHOT_EMAIL = """\
# Example: Safe email action with approval gate
Goal: Email a short status update to alex@example.com.

Thought: I should draft the email first and not send without explicit approval.
Action: {"tool": "email.draft", "args": {"to": ["alex@example.com"], "subject": "Status Update", "body": "Hi Alex, quick update: all tasks on track. -Agent"}}
Observation: {"ok": true, "draft_id": "d_12345"}

Thought: Sending requires approval; I will stop after drafting and report back.
Action: {"tool": "Finish", "args": {"answer": "Draft created. Do you want me to send it?", "evidence": [{"draft_id": "d_12345"}]}}
"""


def _render_tool_catalog(tools: Dict[str, Dict[str, Any]]) -> str:
    """Render a compact, LLM-friendly tool catalog with JSON Schemas."""
    lines = []
    for name in sorted(tools.keys()):
        spec = tools[name]
        desc = spec.get("description", "").strip()
        schema = spec.get("schema", {})
        # Keep schema small to reduce token usage; include required and top-level properties only.
        required = schema.get("required", [])
        props = schema.get("properties", {})
        compact_props = {k: v.get("type", "any") for k, v in props.items()}
        lines.append(f"- {name}\n  description: {desc}\n  required: {json.dumps(required)}\n  properties: {json.dumps(compact_props)}")
    return "TOOLS AVAILABLE:\n" + "\n".join(lines)


def make_react_prompt(
    goal: str,
    tools: Dict[str, Dict[str, Any]],
    reflections: Optional[Iterable[str]] = None,
    context: Optional[str] = None,
    max_steps: int = 7,
    include_examples: bool = True,
) -> str:
    """
    Build the full prompt string:
    - System block with policies and MAX_STEPS.
    - Optional developer context.
    - Tool catalog (dynamic).
    - Optional reflections (lessons learned).
    - Goal
    - Few-shot examples (optional).
    """
    system = REACT_SYSTEM_PROMPT.format(max_steps=max_steps)
    catalog = _render_tool_catalog(tools)

    parts = [system]
    if context:
        parts.append(f"CONTEXT:\n{context.strip()}")
    parts.append(catalog)

    if reflections:
        refl_txt = "\n".join(f"- {r}" for r in reflections if r)
        parts.append(f"REFLECTIONS (optional guidance from previous attempts):\n{refl_txt}")

    parts.append(f"GOAL:\n{goal.strip()}")

    if include_examples:
        parts.append("EXAMPLES:\n" + FEW_SHOT_WEB.strip())
        parts.append(FEW_SHOT_DB.strip())
        parts.append(FEW_SHOT_EMAIL.strip())

    parts.append("Now begin. Remember to use the exact format:\nThought: ...\nAction: {\"tool\": \"<name>\", \"args\": {...}}")
    return "\n\n".join(parts)
