# bridge_http.py
from __future__ import annotations
from typing import Any, Dict, Optional, List

import os
from fastapi import FastAPI
from pydantic import BaseModel

# ReAct + planner + clients
from react_agent import run as react_run
from mcp_safe_adapter import SafeMCPAdapter
from mcp_client import MCPClient as OriginalMCPClient
from gmail_mcp_client import GmailMCPClient

# Reuse the Gemini planner we already wrote in GoverningAgent
# (If you prefer, you can inline a planner here instead.)
from governing_agent import GoverningAgent

app = FastAPI(title="ReAct Agent Gateway", version="1.0")


class ChatIn(BaseModel):
    text: str
    reflections: Optional[List[str]] = None
    intent_hint: Optional[str] = None
    max_steps: Optional[int] = 7
    require_evidence_for_facts: Optional[bool] = True


class ChatOut(BaseModel):
    ok: bool
    answer: str
    evidence: list
    steps_used: int
    trajectory: list
    error: Optional[str] = None


@app.get("/health")
def health() -> Dict[str, str]:
    return {"status": "ok"}


@app.post("/chat", response_model=ChatOut)
def chat(inp: ChatIn) -> Dict[str, Any]:
    # Build your existing clients (use your real constructors/params if needed)
    original_mcp = OriginalMCPClient()     # pass DSN/paths here if your impl needs it
    gmail_client = GmailMCPClient()        # pass creds here if your impl needs it
    safe_mcp = SafeMCPAdapter(original_mcp)

    # Planner: reuse the Gemini-only planner from GoverningAgent
    planner = GoverningAgent._gemini_planner

    # Call the ReAct loop
    result = react_run(
        goal=inp.text,
        planner=planner,
        mcp_client=safe_mcp,
        gmail_client=gmail_client,
        reflections=inp.reflections or [],
        intent_hint=inp.intent_hint,
        max_steps=inp.max_steps or 7,
        require_evidence_for_facts=bool(inp.require_evidence_for_facts),
    )

    # Ensure response schema
    return {
        "ok": bool(result.get("ok", True)),
        "answer": str(result.get("answer", "")),
        "evidence": result.get("evidence", []),
        "trajectory": result.get("trajectory", []),
        "steps_used": int(result.get("steps_used", 0)),
        "error": result.get("error"),
    }
